#ifndef CINISECTION_H
#define CINISECTION_H

#include "CList.h"
#include "CFile.h"
#include "CIniLine.h"

bool isSection(const CString &line);

class CIniSection
{
public:

    CIniSection();

    int     readSectionTxt(const CStringList &allLines, int fromline, int toline);
    bool    writeSectionTxt(CFile &outStream);

    CIniLine* find(const CString &key);

    CStringList childKeys();

    void    setValue(const CString &key, const CString &value);
    CString value(const CString &key, const CString &value = CString());

    CString name() {return _name;}

private:

    CString _name;
    CList   _linesList;

};

#endif // CINISECTION_H


