#include <stdlib.h>
#include "wdirent.h"
#include "strconv.h"
#include "strpath.h"
#include "CDirent.h"

CDirent::CDirent()
{
}

CDirent::CDirent(const char *dirname)
{
    open(dirname);
}

CDirent::~CDirent()
{
    close();
}

bool CDirent::open(const char *basedir, const char *subdir)
{
    if (_dir)
        close();

    _basedir = basedir;
    _subdir = subdir;

    wchar_t *tmp = utf8ToWchar(pathJoin(basedir, subdir));
    _dir = _wopendir(tmp);
    free(tmp);

    if (!_dir)
        return false;

    return true;
}

void CDirent::close()
{
    if (_dir)
    {
        _wclosedir((_WDIR*) _dir);
        _dir = nullptr;
    }
}

bool CDirent::read(CString &result, int *type)
{
    if (!_dir)
        return false;

    readnext:
    struct _wdirent *nextp = _wreaddir((_WDIR*) _dir);

    if (!nextp)
        return false;

    if (_skipdot
        && (wcscmp(nextp->d_name, L".") == 0
            || wcscmp(nextp->d_name, L"..") == 0))
        goto readnext;

    char *tmp = wcharToUtf8(nextp->d_name);
    result = tmp;
    free(tmp);

    if (type)
        *type = nextp->d_type;

    return true;
}


