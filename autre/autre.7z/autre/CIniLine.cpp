#include "CIniLine.h"

CIniLine::CIniLine(const CString &linestr, CLineType linetype)
{
    _setLine(linestr, linetype);
}

void CIniLine::setValue(const CString &value)
{
    if (_type == CLineType::Key)
        _value = value;
}

CString CIniLine::value()
{
    return _value;
}

void CIniLine::_setLine(const CString &linestr, CLineType linetype)
{
    _type = linetype;
    _line = linestr.trimmed();

    if (_type == CLineType::Key)
    {
        int size = _line.size();
        int pos = _line.indexOf("=");

        if (size > 1 && pos > 0)
        {
            _value = _line.mid(pos+1).trimmed();
            _line = _line.left(pos).trimmed();
            return;
        }
    }

    _value = "";
}


