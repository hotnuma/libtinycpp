#ifndef CVECTOR_H
#define CVECTOR_H

#include <stdlib.h>
#define CLST_INITSIZE 1

template<typename T>
class CList
{
public:

    CList<T>();
    ~CList<T>();

    const int capacity();
    const int size();

    void append(const T &obj);
    T& at(int index);

private:

    T **_data = nullptr;
    int _capacity = 0;
    int _size = 0;

};

template<typename T>
CList<T>::CList()
{
    _capacity = CLST_INITSIZE;
    _data = (T**) malloc(_capacity * sizeof(void*));
}

template<typename T>
CList<T>::~CList()
{
    if (_data)
    {
        for (int i = 0; i < _size; ++i)
            delete _data[i];
        free(_data);
    }
}

template<typename T>
const int CList<T>::capacity()
{
    return _capacity;
}

template<typename T>
const int CList<T>::size()
{
    return _size;
}

template<typename T>
void CList<T>::append(const T &obj)
{
    if (!_data)
        return;

    if (_size > 0 && _size == _capacity)
    {
        _capacity *= 2;
        _data = (T**) realloc(_data, _capacity * sizeof(void*));
    }

    _data[_size++] = new T(obj);
}

template<typename T>
T& CList<T>::at(int index)
{
    if (!_data || index < 0 || index >= _size)
        return *_data[0];

    return *_data[index];
}

#endif // CVECTOR_H

