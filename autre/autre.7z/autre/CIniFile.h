#ifndef CINIFILE_H
#define CINIFILE_H

#include "CIniSection.h"

class CIniFile
{
public:

    CIniFile();

    int size() {return _sectionList.size();}
    CIniSection* at(int i) {return (CIniSection*) _sectionList.at(i);}

    bool open(const CString &filepath);
    CIniSection* section(const CString &section);

private:

    int _addSectionTxt(CStringList &allLines, int fromline, int toline);

    CString _filepath;
    CList _sectionList;

};

#if 0
void clear();
bool save();
bool saveAs(const CString &filepath);

CStringList allSections();
#endif

#endif // CINIFILE_H


