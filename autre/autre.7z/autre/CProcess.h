#ifndef CPROCESS_H
#define CPROCESS_H

#include "CString.h"

#define PF_NONE     0x00
#define PF_PIPEIN   0x01
#define PF_PIPEOUT  0x02
#define PF_PIPEERR  0x04
#define PF_MERGEERR 0x08

class CProcess
{
public:

    CProcess();
    ~CProcess();

    void setInput(const char *instr);
    bool start(const CString &command, int flags = PF_NONE);
    int exitStatus() {return _exitCode;}

    CString inBuff;
    CString outBuff;
    CString errBuff;

private:

    int _flags = PF_NONE;

    bool _abort = false;
    long unsigned int _exitCode = 0;

    void _writeToPipe();
    void _readAll();
    void _waitForFinished(void *handle);

    const char *_instr = nullptr;

    void *_inHandles[2] = {0, 0};
    void *_outHandles[2] = {0, 0};
    void *_errHandles[2] = {0, 0};

};

#endif // CPROCESS_H


