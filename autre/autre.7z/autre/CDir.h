#ifndef CDIR_H
#define CDIR_H

#include <wtypes.h>
#include <fileapi.h>
#include "CString.h"

class CDir
{
public:

    CDir(const char *dirpath);
    ~CDir();

    bool hasNext();
    CString next();

private:

    CString _dirpath;
    //WIN32_FIND_DATA _fd;
    bool _next = false;

    void *_find = nullptr;
    void *_fd = nullptr;

};

#endif // CDIR_H

