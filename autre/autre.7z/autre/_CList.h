#ifndef CLIST_H
#define CLIST_H

template<class T>
struct CNode
{
    CNode<T> *prev;
    CNode<T> *next;
    T data;
};

template<class T>
class CList
{
public:
    CNode<T> *first;
    CNode<T> *last;

    CList<T>()
    {
        first = NULL;
        last = NULL;
    }

    void add(T data)
    {
        if (!first)
        {
            // The list is empty
            first = new CNode<T>;
            first->data = data;
            first->next = nullptr;
            last = first;
        }
        else
        {
            // The list isn't empty
            if (last == first)
            {
                // The list has one element
                last = new CNode<T>;
                last->data = data;
                last->next = nullptr;
                first->next = last;
            }
            else
            {
                // The list has more than one element
                CNode<T>* insdata = new CNode<T>;
                insdata->data = data;
                insdata->next = nullptr;
                last->next = insdata;
                last = insdata;
            }
        }
    }

    T get(int index)
    {
        if (index == 0)
        {
            // Get the first element
            return this->first->data;
        }
        else
        {
            // Get the index'th element
            CNode<T>* curr = this->first;
            for (int i = 0; i < index; ++i)
            {
                curr = curr->next;
            }
            return curr->data;
        }
    }

    T operator[](int index)
    {
        return get(index);
    }

};

#endif // CLIST_H


