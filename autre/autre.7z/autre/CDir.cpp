#include "CDir.h"
#include "utf8conv.h"
#include "print.h"

CDir::CDir(const char *dirpath)
{
    _dirpath = dirpath;
}

CDir::~CDir()
{
    if (_fd)
        free(_fd);
}

bool CDir::hasNext()
{
    //print("try next");

    _next = false;

    if (_find == INVALID_HANDLE_VALUE)
        return false;

    if (!_fd)
        _fd = malloc(sizeof(WIN32_FIND_DATA));

    if (!_find)
    {
        CString search_path = _dirpath;
        search_path += "/*";
        wchar_t *wbuff = utf8ToWchar(search_path);
        _find = ::FindFirstFile(wbuff, (WIN32_FIND_DATA*) _fd);
        free(wbuff);

        if (_find == INVALID_HANDLE_VALUE)
        {
            //print("first false");
            return false;
        }

        //print("first true");
        _next = true;
        return _next;
    }

    if (FindNextFile(_find, (WIN32_FIND_DATA*) _fd) == 0)
    {
        //print("next false");
        FindClose(_find);
        _find = INVALID_HANDLE_VALUE;
        return false;
    }

    //print("next true");
    _next = true;
    return _next;
}

CString CDir::next()
{
    CString dir;
    if (!_find || _find == INVALID_HANDLE_VALUE || !_fd || !_next)
        return dir;

    char *str = wcharToUtf8(((WIN32_FIND_DATA*) _fd)->cFileName);
    dir = str;
    free(str);

    return dir;
}


