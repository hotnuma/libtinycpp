#ifndef CVECTOR_H
#define CVECTOR_H

#include <stddef.h>
#include <stdlib.h>
#include <new>
#define INITSIZE 1

template<typename T>
class CVector
{
public:

    CVector<T>();
    ~CVector<T>();

    size_t capacity();
    size_t size();
    void append(const T &obj);
    T& at(size_t index);

private:

    T *_data = nullptr;
    size_t _capacity = 0;
    size_t _size = 0;

};

template<typename T>
CVector<T>::CVector()
{
    _capacity = INITSIZE;
    _data = (T*) malloc(_capacity * sizeof(T));
}

template<typename T>
CVector<T>::~CVector()
{
    if (_data)
    {
        for (size_t i = 0; i < _size; ++i)
            _data[i].~T();
        free(_data);
    }
}

template<typename T>
size_t CVector<T>::capacity()
{
    return _capacity;
}

template<typename T>
size_t CVector<T>::size()
{
    return _size;
}

template<typename T>
void CVector<T>::append(const T &obj)
{
    if (!_data)
        return;

    if (_size > 0 && _size == _capacity)
    {
        _capacity *= 2;
        T *newdata = (T*) malloc(_capacity * sizeof(T));
        for (size_t i = 0; i < _size; ++i)
        {
            new (&newdata[i]) T(_data[i]);
            //newdata[i] = _data[i];
            _data[i].~T();
        }
        free(_data);
        _data = newdata;
    }

    //_data[_size] = obj;

    new (_data + _size) T(obj);

    //*(_data + _length) = obj;
    ++_size;
}

template<typename T>
T& CVector<T>::at(size_t index)
{
    if (!_data || index < 0 || index >= _size)
        return _data[0];

    return _data[index];

    //return *(_data + index);
}


#endif // CVECTOR_H
