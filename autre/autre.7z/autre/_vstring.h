/*
 *   Copyright (c) 1998-2002, Darren Hiebert
 *
 *   This source code is released for free distribution under the terms of the
 *   GNU General Public License version 2 or (at your option) any later version.
 *
 *   Provides the external interface for resizeable strings.
 */
#ifndef CTAGS_MAIN_VSTRING_H
#define CTAGS_MAIN_VSTRING_H

#include "general.h"
#include <stdlib.h>
#include <stdio.h>

#define vstringValue(vs)    ((vs)->buffer)
#define vstringItem(vs, i)  ((vs)->buffer[i])
#define vstringLast(vs)     ((vs)->buffer[(vs)->length - 1])
#define vstringLength(vs)   ((vs)->length)
#define vstringIsEmpty(vs)  ((vs)->length == 0)
#define vstringSize(vs)     ((vs)->size)
#define vstringChar(vs, i)  ((vs)->buffer[i])
#define vstringLower(vs)    toLowerString((vs)->buffer)
#define vstringUpper(vs)    toUpperString((vs)->buffer)

typedef struct vString
{
    char *buffer;
    size_t size;
    size_t length;

} vString;

void vstringResize(vString *const string, const size_t newSize);

CTAGS_INLINE void vstringClear(vString *str)
{
    if (!str)
        return;

    str->length = 0;
    str->buffer[0] = '\0';
}

CTAGS_INLINE void vstringPut(vString *const string, const int c)
{
    if (!string)
        return;

    // check for buffer overflow.
    if (string->length + 1 == string->size)
        vstringResize(string, string->size * 2);

    string->buffer [string->length] = c;
    if (c != '\0')
        string->buffer [++string->length] = '\0';
}

vString* vstringNewSize(size_t size);
vString* vstringNew(void);
void vstringDelete(vString *const string);
void vstringStripNewline(vString *const string);
void vstringStripLeading(vString *const string);
void vstringChop(vString *const string);
void vstringStripTrailing(vString *const string);
void vstringCat(vString *const string, const vString *const s);
void vstringCatS(vString *const string, const char *const s);
void vstringNCat(vString *const string, const vString *const s, const size_t length);
void vstringNCatS(vString *const string, const char *const s, const size_t length);
vString* vstringNewCopy(const vString *const string);
vString* vstringNewInit(const char *const s);
vString* vstringNewNInit(const char *const s, const size_t length);
void vstringCopy(vString *const string, const vString *const s);
void vstringCopyS(vString *const string, const char *const s);
void vstringNCopy(vString *const string, const vString *const s, const size_t length);
void vstringNCopyS(vString *const string, const char *const s, const size_t length);
void vstringCopyToLower(vString *const dest, const vString *const src);
void vstringSetLength(vString *const string);
void vstringTruncate(vString *const string, const size_t length);
void vstringTranslate(vString *const string, char fromC, char toC);

vString* vstringNewOrClear(vString *const string);

vString* vstringNewOwn(char *s);
char* vstringDeleteUnwrap(vString *const string);

void vstringCatSWithEscaping(vString* b, const char *s);
void vstringCatSWithEscapingAsPattern(vString *output, const char* input);

#endif // CTAGS_MAIN_VSTRING_H


