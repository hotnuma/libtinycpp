#include "wdirent.h"
#include "CDirent.h"
#include "CDir.h"
#include "strpath.h"

void _deleteFunc(CDirent *dirent)
{
    if (dirent)
        delete dirent;
}

CDir::CDir()
{
    _list.setDeleteFunc((CListDeleteFunc) _deleteFunc);
}

CDir::~CDir()
{
}

bool CDir::open(const char *dirname)
{
    CDirent *entry = new CDirent();

    if (!entry->open(dirname))
    {
        delete entry;
        return false;
    }

    _list.append(entry);

    return true;
}

int g_count = 250;
bool CDir::read(CString &basedir, CString &subdir, CString &filename)
{
    readnext:
    CDirent *entry = (CDirent*) _list.last();

    if (g_count-- < 0)
        return false;

    if (!entry)
        return false;

    CString result;
    int type;

    if (!entry->read(result, &type))
    {
        _list.removeLast();
        goto readnext;
    }

    if (S_ISDIR(type))
    {
        //CString fullpath = pathJoin(entry->directory(), result);
        CString newsubdir = pathJoin(entry->subdir(), result);
        CDirent *subentry = new CDirent();
        if (!subentry->open(entry->basedir(), newsubdir))
        {
            delete subentry;
            return false;
        }
        _list.append(subentry);
        goto readnext;
    }

    basedir = entry->basedir();
    subdir = entry->subdir();
    filename = result;

    return true;
}


