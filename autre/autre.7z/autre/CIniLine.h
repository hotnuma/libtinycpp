#ifndef CINILINE_H
#define CINILINE_H

#include "CString.h"

enum class CLineType
{
    Undefined,
    Comment,
    Key,
    Empty,
    Error
};

class CIniLine
{
public:

    CIniLine(const CString &linestr, CLineType linetype);

    CLineType   type() {return _type;}
    CString     line() {return _line;}

    void        setValue(const CString &value);
    CString     value();

private:

    void        _setLine(const CString &linestr, CLineType linetype);

    CLineType   _type;
    CString     _line;
    CString     _value;

};

#endif // CINILINE_H


