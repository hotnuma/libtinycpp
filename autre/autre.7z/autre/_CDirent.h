#ifndef CDIRENT_H
#define CDIRENT_H

#include "CString.h"

class CDirent
{
public:

    CDirent();
    CDirent(const char *dirname);
    ~CDirent();

    bool open(const char *basedir, const char *subdir = "");
    void close();
    bool read(CString &result, int *type = nullptr);
    const char* basedir() {return _basedir.c_str();}
    const char* subdir() {return _subdir.c_str();}

private:

    void *_dir = nullptr;
    bool _skipdot = true;

    CString _basedir;
    CString _subdir;

};

#endif // CDIRENT_H


