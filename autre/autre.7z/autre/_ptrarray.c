/*
 *   Copyright (c) 1999-2002, Darren Hiebert
 *
 *   This source code is released for free distribution under the terms of the
 *   GNU General Public License version 2 or (at your option) any later version.
 *
 *   This module contains functions managing resizable pointer arrays.
 */

#include "general.h"

#include <string.h>
#include <stdlib.h>

#include "ptrarray.h"
#include "routines.h"

struct PtrArray
{
    unsigned int max;
    unsigned int count;
    void **array;
    ptrArrayDeleteFunc deleteFunc;
};

PtrArray *ptrArrayNew(ptrArrayDeleteFunc deleteFunc)
{
    PtrArray* const array = vMalloc(PtrArray, 1);
    array->count = 0;
    array->max = 8;
    array->array = vMalloc(void*, array->max);
    array->deleteFunc = deleteFunc;

    return array;
}

void ptrArrayClear(PtrArray *const current)
{
    if (!current)
        return;

    if (current->deleteFunc)
    {
        unsigned int i;
        for (i = 0; i < current->count; ++i)
            current->deleteFunc(current->array [i]);
    }
    current->count = 0;
}

void ptrArrayDelete(PtrArray *const current)
{
    if (!current)
        return;

    ptrArrayClear(current);
    vDelete(current->array);
    vDelete(current);
}

unsigned int ptrArrayCount(const PtrArray *const current)
{
    if (!current)
        return 0;

    return current->count;
}

void* ptrArrayItem(const PtrArray *const current, const unsigned int indx)
{
    if (!current)
        return nullptr;

    return current->array [indx];
}

unsigned int ptrArrayAdd(PtrArray *const current, void *ptr)
{
    if (!current)
        return -1;

    if (current->count == current->max)
    {
        current->max *= 2;
        current->array = vRealloc(current->array, void*, current->max);
    }

    int idx = current->count;
    current->array [current->count++] = ptr;
    return idx;
}

void ptrArrayRemoveLast(PtrArray *const current)
{
    if (!current || current->count < 1)
        return;

    --current->count;
}

void ptrArrayDeleteItem(PtrArray* const current, unsigned int indx)
{
    if (!current)
        return;

    void *ptr = current->array[indx];

    if (current->deleteFunc)
        current->deleteFunc(ptr);

    memmove(current->array + indx, current->array + indx + 1,
            (current->count - indx) * sizeof (*current->array));
    --current->count;
}

/* Combine array `from' into `current', deleting `from' */
void ptrArrayCombine(PtrArray *const current, PtrArray *const from)
{
    unsigned int i;

    if (!current || !from)
        return;

    for (i = 0; i < from->count; ++i)
        ptrArrayAdd(current, from->array [i]);

    from->count = 0;
    ptrArrayDelete(from);
}

void* ptrArrayLast(const PtrArray *const current)
{
    if (!current)
        return nullptr;

    //Assert(current->count > 0);
    return current->array [current->count - 1];
}

bool ptrArrayHasTest(const PtrArray *const current,
                     bool (*test)(const void *ptr, void *userData),
                     void *userData)
{
    if (!current)
        return false;

    bool result = false;
    unsigned int i;
    for (i = 0; !result && i < current->count; ++i)
        result = (*test)(current->array [i], userData);

    return result;
}

static bool ptrEq(const void *ptr, void *userData)
{
    return (ptr == userData);
}

bool ptrArrayHas(const PtrArray *const current, void *ptr)
{
    return ptrArrayHasTest(current, ptrEq, ptr);
}

void ptrArrayReverse(const PtrArray *const current)
{
    if (!current)
        return;

    unsigned int i, j;
    void *tmp;

    for (i = 0, j = current->count - 1; i < (current->count / 2); ++i, --j)
    {
        tmp = current->array[i];
        current->array[i] = current->array[j];
        current->array[j] = tmp;
    }
}

static int (*ptrArraySortCompareVar)(const void *, const void *);

static int ptrArraySortCompare(const void *a0, const void *b0)
{
    void *const *a = (void *const *) a0;
    void *const *b = (void *const *) b0;

    return ptrArraySortCompareVar(*a, *b);
}

void ptrArraySort(PtrArray *const current, int (*compare)(const void *, const void *))
{
    if (!current)
        return;

    ptrArraySortCompareVar = compare;
    qsort(current->array, current->count, sizeof (void *), ptrArraySortCompare);
}


