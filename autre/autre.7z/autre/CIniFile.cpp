#include "libfile.h"
#include "CIniFile.h"

void _deleteSection(CIniSection *section)
{
    if (section)
        delete section;
}

CIniFile::CIniFile()
{
    _sectionList.setDeleteFunc((CListDeleteFunc) _deleteSection);
}

CIniSection* CIniFile::section(const CString &section)
{
    int size = _sectionList.size();
    for (int i = 0; i < size; ++i)
    {
        CIniSection *iniSection = (CIniSection*) _sectionList[i];
        if (iniSection->name() == section)
            return iniSection;
    }

    return nullptr;
}

bool CIniFile::open(const CString &filepath)
{
    CString buffer;

    if (!fileRead(filepath, buffer))
        return false;

    _filepath = filepath;

    buffer.replace("\r", "");
    CStringList allLines = buffer.split("\n");

    int size = allLines.size();
    if (!size)
        return true;

    if (allLines.at(size-1).trimmed() != "")
    {
        allLines.append("");
        ++size;
    }

    // Parse all lines.
    int start = 0;
    int current = 0;

    while (true)
    {
        CString line = allLines.at(current).trimmed();

        // Group or eol.
        if (isSection(line))
        {
            if (_addSectionTxt(allLines, start, current) < 0)
                return false;

            start = current;
        }

        // Add last block.
        else if (current+1 >= size)
        {
            int ret = _addSectionTxt(allLines, start, current);
            if (ret < 0)
                return false;

            break;
        }

        ++current;
    }

    return true;
}

int CIniFile::_addSectionTxt(CStringList &allLines, int fromline, int toline)
{
    CIniSection *section = new CIniSection();
    int ret = section->readSectionTxt(allLines, fromline, toline);
    if (ret < 1)
    {
        delete section;
        return ret;
    }

    _sectionList.append(section);
    return ret;
}




#if 0
















bool CIniFile::save()
{
    // Output file.
    CFile outFile;
    if (!outFile.open(_filepath, "wb"))
        return false;

    //foreach (CIniSection *section, _sectionList)
    int size = _sectionList.size();
    for (int i = 0; i < size; ++i)
    {
        CIniSection *section = (CIniSection*) _sectionList[i];
        section->writeSectionTxt(outFile);
    }

    return true;
}

bool CIniFile::saveAs(const CString &filepath)
{
    _filepath = filepath;

    return save();
}

CStringList CIniFile::allSections()
{
    CStringList result;

    int size = _sectionList.size();
    for (int i = 0; i < size; ++i)
    {
        CIniSection *section = (CIniSection*) _sectionList[i];
        result.append(section->name());
    }

    return result;
}

#endif


