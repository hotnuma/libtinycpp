#ifndef CDIR_H
#define CDIR_H

#include "CString.h"
#include "CList.h"

class CDir
{
public:

    CDir();
    ~CDir();

    bool open(const char *dirname);
    bool read(CString &basedir, CString &subdir, CString &filename);

private:

    CList _list;

};

#endif // CDIR_H


