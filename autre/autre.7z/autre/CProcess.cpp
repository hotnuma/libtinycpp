#include <wtypes.h>
#include <winbase.h>
#include <handleapi.h>
#include "strconv.h"
#include "CProcess.h"

#define HREAD 0
#define HWRITE 1

void _closeHandle(void **ptr)
{
    if (!ptr || !*ptr)
        return;

    CloseHandle(*ptr);
    *ptr = nullptr;
}

bool _readPipe(void *handle, CString &outBuff)
{
    if (!handle)
        return false;

    DWORD avail;
    if (!PeekNamedPipe(handle, 0, 0, 0, &avail, 0))
    {
        //print("peek error");
        return false;
    }

    if (!avail)
        return true;

    //print("peek = %i", avail);

    int length = outBuff.size();
    outBuff.resize(length + avail + 1);

    char *buff = outBuff.data() + length;
    DWORD numRead;

    if (!ReadFile(handle, buff, avail, &numRead, 0))
    {
        //print("read error");
        return false;
    }

    int num = (numRead < avail) ? numRead : avail;
    outBuff.terminate(length + num);

    //print("read = %i", numRead);
    //print(outBuff);

    return true;
}

CProcess::CProcess()
{
}

CProcess::~CProcess()
{
}

void CProcess::setInput(const char *instr)
{
    _instr = instr;
}

void CProcess::_writeToPipe()
{
    DWORD dwWritten;

    if (_instr)
    {
        //print("write");

        int len = strlen(_instr);
        WriteFile(_inHandles[HWRITE], _instr, len, &dwWritten, NULL);

        //if (!result)
        //    print("write error");

        //print("writen = %i", dwWritten);
    }

    _closeHandle(&_inHandles[HWRITE]);

    return;
}

void CProcess::_readAll()
{
    if (_outHandles[HREAD])
        _readPipe(_outHandles[HREAD], outBuff);

    if (_errHandles[HREAD])
        _readPipe(_errHandles[HREAD], errBuff);
}

void CProcess::_waitForFinished(void *handle)
{
    while (1)
    {
        Sleep(50);

        _readAll();

        GetExitCodeProcess(handle, &_exitCode);
        if (_exitCode != STILL_ACTIVE)
        {
            _readAll();

            //print("finished");
            break;
        }
        else if (_abort)
        {
            _exitCode = ERROR_CANCELLED;
            TerminateProcess(handle, 1);
            break;
        }
    }
}

bool CProcess::start(const CString &command, int flags)
{
    _flags = flags;
    _exitCode = -1;

    SECURITY_ATTRIBUTES saAttr;
    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
    saAttr.bInheritHandle = true;
    saAttr.lpSecurityDescriptor = nullptr;

    // Create a pipe for the child process's STDIN.
    if (_flags & PF_PIPEIN)
    {
        if (!CreatePipe(&_inHandles[HREAD], &_inHandles[HWRITE], &saAttr, 0)
            || !SetHandleInformation(_inHandles[HWRITE], HANDLE_FLAG_INHERIT, 0))
            return false;
    }

    // Create a pipe for the child process's STDOUT.
    if (_flags & PF_PIPEOUT)
    {
        if (!CreatePipe(&_outHandles[HREAD], &_outHandles[HWRITE], &saAttr, 0)
            || !SetHandleInformation(_outHandles[HREAD], HANDLE_FLAG_INHERIT, 0))
            return false;
    }

    // Create a pipe for the child process's STDOUT.
    if ((_flags & PF_PIPEERR) && !(_flags & PF_MERGEERR))
    {
        if (!CreatePipe(&_errHandles[HREAD], &_errHandles[HWRITE], &saAttr, 0)
            || !SetHandleInformation(_errHandles[HREAD], HANDLE_FLAG_INHERIT, 0))
            return false;
    }

    PROCESS_INFORMATION pi;
    STARTUPINFOW siw;
    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&siw, sizeof(STARTUPINFOW));

    siw.cb = sizeof(STARTUPINFOW);
    if (_flags & PF_PIPEIN)
        siw.hStdInput = _inHandles[HREAD];

    if (_flags & PF_PIPEOUT)
        siw.hStdOutput = _outHandles[HWRITE];

    if (_flags & PF_MERGEERR)
        siw.hStdError = _outHandles[HWRITE];
    else if (_flags & PF_PIPEERR)
        siw.hStdError = _errHandles[HWRITE];

    siw.dwFlags |= STARTF_USESTDHANDLES;

    wchar_t *wbuff = utf8ToWchar(command.c_str());

    bool result = CreateProcessW(
                    0,              // application name
                    wbuff,          // command line
                    0,              // process security attributes
                    0,              // primary thread security attributes
                    true,           // handles are inherited
                    0,              // creation flags
                    0,              // use parent's environment
                    0,              // use parent's current directory
                    &siw,   // STARTUPINFO pointer
                    &pi);   // receives PROCESS_INFORMATION

    free(wbuff);

    _closeHandle(&_inHandles[HREAD]);
    _closeHandle(&_outHandles[HWRITE]);
    _closeHandle(&_errHandles[HWRITE]);

    // If an error occurs, exit the application.
    if (!result)
    {
        _closeHandle(&_inHandles[HWRITE]);
        _closeHandle(&_outHandles[HREAD]);
        _closeHandle(&_errHandles[HREAD]);

        GetExitCodeProcess(pi.hProcess, &_exitCode);

        return false;
    }

    if (_inHandles[HWRITE])
        _writeToPipe();

    // Read from pipe that is the standard output for child process.
    _waitForFinished(pi.hProcess);

    _closeHandle(&_inHandles[HWRITE]);
    _closeHandle(&_outHandles[HREAD]);
    _closeHandle(&_errHandles[HREAD]);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    return (_exitCode == 0);
}


