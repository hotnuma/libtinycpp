/*
 *   Copyright (c) 1999-2002, Darren Hiebert
 *
 *   This source code is released for free distribution under the terms of the
 *   GNU General Public License version 2 or (at your option) any later version.
 *
 *   Defines external interface to resizable pointer arrays.
 */
#ifndef CTAGS_MAIN_PTRARRAY_H
#define CTAGS_MAIN_PTRARRAY_H

#include "general.h"

typedef struct PtrArray PtrArray;
typedef void (*ptrArrayDeleteFunc) (void *data);

PtrArray *ptrArrayNew(ptrArrayDeleteFunc deleteFunc);
unsigned int ptrArrayAdd(PtrArray *const current, void *ptr);
void ptrArrayRemoveLast(PtrArray *const current);
void ptrArrayCombine(PtrArray *const current, PtrArray *const from);
void ptrArrayClear(PtrArray *const current);
unsigned int ptrArrayCount(const PtrArray *const current);
void* ptrArrayItem(const PtrArray *const current, const unsigned int indx);
void* ptrArrayLast(const PtrArray *const current);
void ptrArrayDelete(PtrArray *const current);
bool ptrArrayHasTest(const PtrArray *const current,
                     bool (*test)(const void *ptr, void *userData),
                     void *userData);
bool ptrArrayHas(const PtrArray *const current, void *ptr);
void ptrArrayReverse(const PtrArray *const current);
void ptrArrayDeleteItem(PtrArray* const current, unsigned int indx);

void ptrArraySort(PtrArray *const current, int (*compare)(const void *, const void *));

#endif  /* CTAGS_MAIN_PTRARRAY_H */


