#include <dirent.h>
#include "print.h"
#include "CDir.h"

CDir::CDir(const char *dirpath)
{
    _dirpath = dirpath;
}

CDir::~CDir()
{
    close();
}

bool CDir::open(const char *dirname)
{
    if (_dir)
        close();

    _dir = opendir(dirname);
    if (!_dir)
        return false;

    return true;
}

void CDir::close()
{
    _nextp = nullptr;

    if (!_dir)
        return;

    closedir((DIR*) _dir);
    _dir = nullptr;
}

bool CDir::hasNext()
{
    if (!_dir)
    {
        _dir = opendir(_dirpath);
        if (!_dir)
            return false;
    }

    _nextp = readdir((DIR*) _dir);

    if (!_nextp)
        close();

    return (_nextp != nullptr);
}

CString CDir::next()
{
    CString dir;
    if (!_nextp)
        return dir;

    dir = _nextp->d_name;
    return dir;
}


