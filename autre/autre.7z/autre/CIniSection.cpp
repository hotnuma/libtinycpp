#include "CIniSection.h"

int _isValidRange(int fromline, int toline)
{
    int range = toline - fromline;

    if (fromline < 0)
    {
        //print("*** isValidRange: negative start of block.");
        return -1;
    }
    else if (toline < 0)
    {
        //print("*** isValidRange: negative end of block.");
        return -1;
    }
    else if (range < 0)
    {
        //print("*** isValidRange: negative range.");
        return -1;
    }
    else if (range > 1024)
    {
        //print("*** isValidRange: too much lignes in current block.");
        return -1;
    }
    else if (range == 0)
    {
        return 0;
    }

    return range;
}

bool isSection(const CString &line)
{
    return line.size() > 2 && line.startsWith("[") && line.endsWith("]");
}

bool getSection(const CString &line, CString &result)
{
    if (!isSection(line))
    {
        result = "";
        return false;
    }

    result = line.mid(1, line.size() - 2);
    return true;
}

void _deleteLine(CIniLine *line)
{
    if (line)
        delete line;
}

CIniSection::CIniSection()
{
    _linesList.setDeleteFunc((CListDeleteFunc) _deleteLine);
}

int CIniSection::readSectionTxt(const CStringList &allLines, int fromline, int toline)
{
    int ret = _isValidRange(fromline, toline);
    if (ret < 1)
        return ret;

    CString first = allLines[fromline].trimmed();

    if (!getSection(first, _name))
    {
        if (fromline > 0)
            return -1;
    }
    else
    {
        fromline++; // Skip section line.
    }

    for (int current = fromline; current < toline; current++)
    {
        CString line = allLines[current].trimmed();

        CLineType type = CLineType::Undefined;
        int pos = 0;
        if (line.startsWith("#"))
        {
            type = CLineType::Comment;
        }
        else if ((pos = line.indexOf("=")) > 1)
        {
            type = CLineType::Key;

            //int len = line.size();
            //int start = pos + 1;
            //while (start < len && line.at(start++) == " ");

            //if (start < len && line.at(start) == "\"")
            //{
            //    int end = line.indexOf("\"", start+1);
            //    if (end > n)
            //    {

            //    }

            //    CIniLine *iniLine = new CIniLine(line, type);
            //    _linesList << iniLine;
            //    continue;
            //}
        }
        else if (line == "")
        {
            type = CLineType::Empty;
        }
        else
        {
            type = CLineType::Error;
        }

        CIniLine *iniLine = new CIniLine(line, type);
        _linesList.append(iniLine);
    }

    return (toline - fromline);
}

bool CIniSection::writeSectionTxt(CFile &outFile)
{
    if (_name != "")
        outFile << strFmt("[%s]\n", _name.c_str());

    //foreach (CIniLine *iniLine, _linesList)
    int size = _linesList.size();
    for (int i = 0; i < size; ++i)
    {
        CIniLine *iniLine = (CIniLine*) _linesList[i];
        if (iniLine->type() == CLineType::Key)
        {
            outFile << strFmt("%s=%s\n", iniLine->line().c_str(), iniLine->value().c_str());
        }
        else
        {
            outFile << strFmt("%s\n", iniLine->line().c_str());
        }
    }

    return true;
}

CIniLine *CIniSection::find(const CString &key)
{
    int size = _linesList.size();
    for (int i = 0; i < size; ++i)
    {
        CIniLine *iniLine = (CIniLine*) _linesList[i];
        if (iniLine->type() == CLineType::Key
            && iniLine->line() == key)
        {
            return iniLine;
        }
    }

    return nullptr;
}

CStringList CIniSection::childKeys()
{
    CStringList result;

    int size = _linesList.size();
    for (int i = 0; i < size; ++i)
    {
        CIniLine *iniLine = (CIniLine*) _linesList[i];
        if (iniLine->type() == CLineType::Key)
        {
            result.append(iniLine->line());
        }
    }

    return result;
}

void CIniSection::setValue(const CString &key, const CString &value)
{
    CIniLine *iniLine = find(key);

    if (!iniLine)
        return;

    iniLine->setValue(value);
}

CString CIniSection::value(const CString &key, const CString &value)
{
    CIniLine *iniLine = find(key);
    if (!iniLine)
        return value;

    return iniLine->value();
}


