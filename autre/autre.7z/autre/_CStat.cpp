#include <stdlib.h>
#include "strconv.h"

#include "CStat.h"

//#define S_ISLNK(mode) false

//#ifndef S_IXGRP
//#define S_IXGRP 0
//#endif

//#ifndef S_IXOTH
//#define S_IXOTH 0
//#endif

//#ifndef S_ISUID
//#define S_ISUID 0
//#endif

//#ifndef S_ISGID
//#define S_ISGID 0
//#endif

CStat::CStat(const char *filepath)
{
    read(filepath);
}

CStat::CStat()
{
}

CStat::~CStat()
{
    if (_filepath)
        free(_filepath);
}

unsigned long CStat::size()
{
    return _status.st_size;
}

unsigned long CStat::mtime()
{
    return _status.st_mtime;
}

bool CStat::read(const char *filepath)
{
    _valid = false;

    _filepath = strdup(filepath);

    wchar_t* wbuff = utf8ToWchar(_filepath);

    if (_wstat64(wbuff, &_status) != 0)
    {
        free(wbuff);
        return _valid;
    }

    free(wbuff);

    _valid = true;

    //_isDirectory = (bool) S_ISDIR(_status.st_mode);
    //_isNormalFile = (bool) (S_ISREG(_status.st_mode));
    //_isExecutable = (bool) ((_status.st_mode &
    //                        (S_IXUSR | S_IXGRP | S_IXOTH)) != 0);
    //_isSetuid = (bool) ((_status.st_mode & S_ISUID) != 0);
    //_isSetgid = (bool) ((_status.st_mode & S_ISGID) != 0);
    //_size = _status.st_size;

    return true;
}


