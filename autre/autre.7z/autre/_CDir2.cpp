#include <stdlib.h>
#include "wdirent.h"
#include "utf8conv.h"
#include "CDir.h"

//#include "print.h"

CDir::CDir(const char *dirpath)
{
    _dirpath = dirpath;
}

CDir::~CDir()
{
    close();
}

bool CDir::open(const char *dirname)
{
    if (_dir)
        close();

    wchar_t *tmp = utf8ToWchar(dirname);
    _dir = _wopendir(tmp);
    free(tmp);

    if (!_dir)
        return false;

    return true;
}

void CDir::close()
{
    _nextp = nullptr;

    if (!_dir)
        return;

    _wclosedir((_WDIR*) _dir);
    _dir = nullptr;
}

bool CDir::hasNext()
{
    if (!_dir)
    {
        wchar_t *tmp = utf8ToWchar(_dirpath);
        _dir = _wopendir(tmp);
        free(tmp);

        if (!_dir)
            return false;
    }

    _nextp = _wreaddir((_WDIR*) _dir);

    if (!_nextp)
        close();

    return (_nextp != nullptr);
}

CString CDir::next()
{
    CString dir;
    if (!_nextp)
        return dir;

    char *tmp = wcharToUtf8(_nextp->d_name);
    dir = tmp;
    free(tmp);

    return dir;
}


