#ifndef CSTAT_H
#define CSTAT_H

#include <sys/stat.h>

class CStat
{
public:

    CStat(const char *filepath);
    CStat();
    ~CStat();

    bool read(const char *filepath);

    const char* path() {return _filepath;}
    bool exists() {return _valid;}

    //bool isSymbolicLink();
    //bool isDirectory();
    //bool isNormalFile();
    //bool isExecutable();

    // Taille du fichier en octets ; un entier 64 bits pour les variantes avec le i64 suffixe.
    unsigned long size();

    // Heure de dernière modification du fichier.
    unsigned long mtime();

    // Heure du dernier accès au fichier. Valide sur NTFS,
    // mais pas sur les lecteurs de disque au format FAT.
    //st_atime

    // Heure de création du fichier. Valide sur NTFS,
    // mais pas sur les lecteurs de disque au format FAT.
    //st_ctime

    // Numéro du disque contenant le fichier du lecteur (même en tant que st_rdev).
    //st_dev

    // Masque de bits pour les informations relatives au mode de fichier. Le _S_IFDIR bit est défini si chemin d’accès spécifie un répertoire ; le _S_IFREG bit est défini si chemin d’accès spécifie un fichier ordinaire ou un périphérique. Les bits de lecture/écriture utilisateur sont définis en fonction du mode d’autorisation du fichier. Les bits d’exécution utilisateur sont définis en fonction de l’extension de nom de fichier.
    //st_mode

    // Toujours 1 sur les systèmes de fichiers autres que NTFS.
    //st_nlink

    // Numéro du disque contenant le fichier du lecteur (même en tant que st_dev).
    //st_rdev

private:

    struct _stat64 _status;

    // Name of file for which status is valid.
    char *_filepath = nullptr;

    // Does file exist? If not, members below do not contain valid data.
    bool _valid = false;

};

#endif // CSTAT_H


