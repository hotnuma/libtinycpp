#ifndef CDIR_H
#define CDIR_H

#include "CString.h"

class CDir
{
public:

    CDir(const char *dirpath);
    ~CDir();

    bool open(const char*dirname);
    void close();
    bool hasNext();
    CString next();

private:

    CString _dirpath;
    void *_dir = nullptr;
    struct _wdirent *_nextp = nullptr;

};

#endif // CDIR_H

